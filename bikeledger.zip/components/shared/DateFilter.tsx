
import React from 'react';
import type { DateFilterOption } from '../../types';

interface DateFilterProps {
  selected: DateFilterOption;
  onChange: (selected: DateFilterOption) => void;
}

const DateFilter: React.FC<DateFilterProps> = ({ selected, onChange }) => {
  const options: { value: DateFilterOption; label: string }[] = [
    { value: 'today', label: 'Today' },
    { value: 'this_week', label: 'This Week' },
    { value: 'this_month', label: 'This Month' },
  ];

  return (
    <div className="flex items-center bg-white rounded-lg shadow-sm border border-gray-200">
      {options.map((option) => (
        <button
          key={option.value}
          onClick={() => onChange(option.value)}
          className={`px-4 py-2 text-sm font-medium transition-colors focus:outline-none 
            ${selected === option.value 
              ? 'bg-primary text-white rounded-md m-1' 
              : 'text-gray-600 hover:bg-gray-100 rounded-md m-1'
            }`}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
};

export default DateFilter;
