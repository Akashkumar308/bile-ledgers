
import React from 'react';
import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
    title: string;
    value: string;
    Icon: LucideIcon;
    color: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, Icon, color }) => {
    return (
        <div className="bg-white p-6 rounded-2xl shadow-md flex items-center">
            <div className={`p-4 rounded-full`} style={{ backgroundColor: `${color}1A`}}>
                <Icon size={28} style={{ color: color }} />
            </div>
            <div className="ml-4">
                <p className="text-sm text-gray-500 font-medium">{title}</p>
                <p className="text-2xl font-bold text-gray-800">{value}</p>
            </div>
        </div>
    );
};

export default StatCard;
