
import React from 'react';

interface PageHeaderProps {
    title: string;
    children?: React.ReactNode;
}

const PageHeader: React.FC<PageHeaderProps> = ({ title, children }) => {
    return (
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-4 md:mb-0">{title}</h2>
            <div className="flex items-center space-x-2">
                {children}
            </div>
        </div>
    );
}

export default PageHeader;
