
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

interface BackButtonProps {
  className?: string;
}

const BackButton: React.FC<BackButtonProps> = ({ className = '' }) => {
  const navigate = useNavigate();

  const defaultClasses = "flex items-center gap-2 text-gray-600 hover:text-gray-900 font-medium transition-colors p-2 rounded-lg hover:bg-gray-100";

  return (
    <button
      onClick={() => navigate(-1)}
      className={`${defaultClasses} ${className}`}
      aria-label="Go back to previous page"
    >
      <ArrowLeft size={20} />
      <span>Back</span>
    </button>
  );
};

export default BackButton;
