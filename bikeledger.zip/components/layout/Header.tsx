
import React from 'react';
import { useLocation } from 'react-router-dom';
import { Bell, UserCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const Header: React.FC = () => {
  const location = useLocation();
  const { currentUser } = useAuth();
  
  const getPageTitle = () => {
      const path = location.pathname;
      if (path.includes('/dashboard')) return 'Dashboard';
      if (path.includes('/sales')) return 'Counter Sales';
      if (path.includes('/expenses')) return 'Expenses';
      if (path.includes('/services')) return 'Bike Services';
      if (path.includes('/reports/profit-loss')) return 'Profit & Loss Report';
      return 'BikeLedger';
  }

  return (
    <header className="flex items-center justify-between h-20 px-8 bg-white border-b">
      <h2 className="text-2xl font-semibold text-gray-800">{getPageTitle()}</h2>
      <div className="flex items-center space-x-6">
        <button className="p-2 text-gray-500 rounded-full hover:bg-gray-100 hover:text-gray-700">
            <Bell size={22}/>
        </button>
        {currentUser && (
          <div className="flex items-center">
              <UserCircle size={32} className="text-gray-500"/>
              <div className="ml-3">
                  <p className="text-sm font-semibold text-gray-800">{currentUser.username}</p>
                  <p className="text-xs text-gray-500">{currentUser.email}</p>
              </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;