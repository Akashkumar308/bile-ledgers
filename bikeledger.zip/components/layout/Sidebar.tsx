
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, ShoppingCart, CreditCard, Wrench, BarChart, Bike, LogOut } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';


const Sidebar: React.FC = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const navLinks = [
    { to: '/dashboard', text: 'Dashboard', Icon: LayoutDashboard },
    { to: '/sales', text: 'Counter Sale', Icon: ShoppingCart },
    { to: '/expenses', text: 'Expenses', Icon: CreditCard },
    { to: '/services', text: 'Bike Services', Icon: Wrench },
    { to: '/reports/profit-loss', text: 'Profit & Loss', Icon: BarChart },
  ];

  interface NavItemProps {
    to: string;
    text: string;
    Icon: LucideIcon;
  }
  
  const NavItem: React.FC<NavItemProps> = ({ to, text, Icon }) => {
      const baseClasses = "flex items-center px-4 py-3 text-gray-700 hover:bg-primary-light hover:text-primary-text rounded-lg transition-colors";
      const activeClasses = "bg-primary-light text-primary-text font-semibold";
      
      return (
          <NavLink
              to={to}
              className={({ isActive }) => `${baseClasses} ${isActive ? activeClasses : ''}`}
          >
              <Icon className="w-5 h-5 mr-3" />
              <span>{text}</span>
          </NavLink>
      );
  }

  const handleLogout = () => {
    logout();
    navigate('/login');
  }

  return (
    <div className="w-64 bg-white shadow-lg flex-shrink-0 hidden md:flex flex-col">
      <div className="flex items-center justify-center h-20 border-b flex-shrink-0">
         <Bike className="h-8 w-8 text-primary" />
        <h1 className="text-2xl font-bold text-gray-800 ml-2">BikeLedger</h1>
      </div>
      <nav className="mt-6 px-4 flex-grow">
        {navLinks.map((link) => (
          <NavItem key={link.to} {...link} />
        ))}
      </nav>
      <div className="p-4 border-t">
          <button onClick={handleLogout} className="flex items-center w-full px-4 py-3 text-gray-700 hover:bg-danger-light hover:text-danger-text rounded-lg transition-colors">
              <LogOut className="w-5 h-5 mr-3" />
              <span>Logout</span>
          </button>
      </div>
    </div>
  );
};

export default Sidebar;