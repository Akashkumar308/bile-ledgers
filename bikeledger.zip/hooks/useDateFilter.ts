
import { useState, useMemo } from 'react';
import type { DateFilterOption } from '../types';

export const useDateFilter = (initialState: DateFilterOption = 'this_month') => {
  const [filter, setFilter] = useState<DateFilterOption>(initialState);

  const dateRange = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    let startDate: Date | null = new Date(today);
    let endDate: Date | null = new Date();
    endDate.setHours(23, 59, 59, 999);

    switch (filter) {
      case 'today':
        break;
      case 'this_week':
        const dayOfWeek = today.getDay();
        startDate.setDate(today.getDate() - dayOfWeek);
        break;
      case 'this_month':
        startDate = new Date(today.getFullYear(), today.getMonth(), 1);
        break;
      default:
        startDate = null;
        endDate = null;
    }
    
    return {
      startDate: startDate ? startDate.toISOString() : undefined,
      endDate: endDate ? endDate.toISOString() : undefined,
    };
  }, [filter]);

  return { filter, setFilter, dateRange };
};
