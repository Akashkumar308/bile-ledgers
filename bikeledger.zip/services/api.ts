
// FIX: Import BikeSpec to be used in the new API methods.
import { Sale, Expense, BikeService, PaymentMethod, DashboardData, ProfitLossSummary, BikeSpec } from '../types';
import { getCurrentUser } from './auth';


// Mock Database with persistence
let sales: Sale[] = [];
let expenses: Expense[] = [];
let bikeServices: BikeService[] = [];
// FIX: Add bikeSpecs array to support the Settings page functionality.
let bikeSpecs: BikeSpec[] = [];
let nextId = 1;

interface AppData {
    sales: Sale[];
    expenses: Expense[];
    bikeServices: BikeService[];
    // FIX: Add bikeSpecs to the AppData interface for local storage persistence.
    bikeSpecs: BikeSpec[];
    nextId: number;
}

const getDbKey = (): string | null => {
    const user = getCurrentUser();
    if (!user) return null;
    return `bikeShopData_${user.id}`;
}

const saveDB = () => {
    const dbKey = getDbKey();
    if(!dbKey) return;
    // FIX: Include bikeSpecs when saving data to local storage.
    const data: AppData = { sales, expenses, bikeServices, bikeSpecs, nextId };
    localStorage.setItem(dbKey, JSON.stringify(data));
};

const loadDB = () => {
    const dbKey = getDbKey();
    if (!dbKey) {
        clearApiData();
        return;
    }

    const dataStr = localStorage.getItem(dbKey);
    if (dataStr) {
        const data: AppData = JSON.parse(dataStr);
        sales = data.sales || [];
        expenses = data.expenses || [];
        bikeServices = data.bikeServices || [];
        // FIX: Load bikeSpecs from local storage.
        bikeSpecs = data.bikeSpecs || [];
        nextId = data.nextId || 1;
    } else {
        clearApiData(); // Start with fresh data for new user
        seedData();
        saveDB();
    }
};

export const initApiForUser = () => {
    loadDB();
}

export const clearApiData = () => {
    sales = [];
    expenses = [];
    bikeServices = [];
    // FIX: Clear bikeSpecs array when clearing user data.
    bikeSpecs = [];
    nextId = 1;
}

// Seed Data
const seedData = () => {
  const today = new Date();
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
  
  const generateRandomDate = (start: Date, end: Date): string => {
    return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime())).toISOString();
  }

  // Sales
  for (let i = 0; i < 25; i++) {
    const qty = Math.floor(Math.random() * 3) + 1;
    const rate = Math.floor(Math.random() * 500) + 100;
    sales.push({
      id: `sale_${nextId++}`,
      serviceName: `Service #${i+1}`,
      qty,
      rate,
      totalAmount: qty * rate,
      paymentMethod: Math.random() > 0.4 ? PaymentMethod.GPay : PaymentMethod.Cash,
      date: generateRandomDate(startOfMonth, endOfMonth),
    });
  }

  // Expenses
  const categories = ['Rent', 'Spares', 'Utilities', 'Salary', 'Misc'];
  for (let i = 0; i < 15; i++) {
    expenses.push({
      id: `exp_${nextId++}`,
      category: categories[Math.floor(Math.random() * categories.length)],
      description: `Expense detail ${i+1}`,
      amount: Math.floor(Math.random() * 2000) + 500,
      date: generateRandomDate(startOfMonth, endOfMonth),
    });
  }
  
  // Bike Services
  for (let i = 0; i < 10; i++) {
      bikeServices.push({
          id: `bs_${nextId++}`,
          customerName: `Customer ${i+1}`,
          bikeNumber: `TN38AB${1000+i}`,
          serviceDetails: `General service, oil change for bike ${i+1}`,
          serviceCost: Math.floor(Math.random() * 1500) + 800,
          paymentMethod: Math.random() > 0.5 ? PaymentMethod.GPay : PaymentMethod.Cash,
          date: generateRandomDate(startOfMonth, endOfMonth)
      });
  }
};

const apiCall = <T,>(data: T, delay = 200): Promise<T> => {
    return new Promise(resolve => setTimeout(() => resolve(data), delay));
}

// --- Sales API ---
export const getSales = async (filters: { startDate?: string; endDate?: string; paymentMethod?: PaymentMethod | 'all'; q?: string }): Promise<Sale[]> => {
    let filteredSales = sales;

    if (filters.startDate) {
        filteredSales = filteredSales.filter(s => new Date(s.date) >= new Date(filters.startDate as string));
    }
    if (filters.endDate) {
        filteredSales = filteredSales.filter(s => new Date(s.date) <= new Date(filters.endDate as string));
    }
    if (filters.paymentMethod && filters.paymentMethod !== 'all') {
        filteredSales = filteredSales.filter(s => s.paymentMethod === filters.paymentMethod);
    }
    if (filters.q) {
        filteredSales = filteredSales.filter(s => s.serviceName.toLowerCase().includes((filters.q as string).toLowerCase()));
    }

    return apiCall([...filteredSales].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
}

export const addSale = async (sale: Omit<Sale, 'id' | 'totalAmount'>): Promise<Sale> => {
    const newSale: Sale = {
        ...sale,
        id: `sale_${nextId++}`,
        totalAmount: sale.qty * sale.rate,
    };
    sales.unshift(newSale);
    saveDB();
    return apiCall(newSale);
}

export const updateSale = async (id: string, updatedSale: Partial<Sale>): Promise<Sale> => {
    const index = sales.findIndex(s => s.id === id);
    if (index === -1) throw new Error("Sale not found");
    
    const sale = sales[index];
    const newSaleData = {...sale, ...updatedSale};
    if(typeof updatedSale.qty !== 'undefined' || typeof updatedSale.rate !== 'undefined') {
        newSaleData.totalAmount = newSaleData.qty * newSaleData.rate;
    }
    
    sales[index] = newSaleData;
    saveDB();
    return apiCall(sales[index]);
}

export const deleteSale = async (id: string): Promise<{ success: boolean }> => {
    sales = sales.filter(s => s.id !== id);
    saveDB();
    return apiCall({ success: true });
}

// --- Expenses API ---
export const getExpenses = async (filters: { startDate?: string; endDate?: string; category?: string | 'all'; q?: string }): Promise<Expense[]> => {
    let filteredExpenses = expenses;

    if (filters.startDate) {
        filteredExpenses = filteredExpenses.filter(e => new Date(e.date) >= new Date(filters.startDate as string));
    }
    if (filters.endDate) {
        filteredExpenses = filteredExpenses.filter(e => new Date(e.date) <= new Date(filters.endDate as string));
    }
    if (filters.category && filters.category !== 'all') {
        filteredExpenses = filteredExpenses.filter(e => e.category === filters.category);
    }
    if (filters.q) {
        filteredExpenses = filteredExpenses.filter(e => e.description.toLowerCase().includes((filters.q as string).toLowerCase()));
    }
    
    return apiCall([...filteredExpenses].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
}

export const getExpenseCategories = async (): Promise<string[]> => {
    const categories = new Set(expenses.map(e => e.category));
    return apiCall(Array.from(categories));
}


export const addExpense = async (expense: Omit<Expense, 'id'>): Promise<Expense> => {
    const newExpense: Expense = {
        ...expense,
        id: `exp_${nextId++}`,
    };
    expenses.unshift(newExpense);
    saveDB();
    return apiCall(newExpense);
}

export const updateExpense = async (id: string, updatedExpense: Partial<Expense>): Promise<Expense> => {
    const index = expenses.findIndex(e => e.id === id);
    if (index === -1) throw new Error("Expense not found");
    expenses[index] = { ...expenses[index], ...updatedExpense };
    saveDB();
    return apiCall(expenses[index]);
}

export const deleteExpense = async (id: string): Promise<{ success: boolean }> => {
    expenses = expenses.filter(e => e.id !== id);
    saveDB();
    return apiCall({ success: true });
}

// --- Bike Services API ---
export const getBikeServices = async (filters: { startDate?: string; endDate?: string; q?: string }): Promise<BikeService[]> => {
    let filteredServices = bikeServices;
    
    if (filters.startDate) {
        filteredServices = filteredServices.filter(s => new Date(s.date) >= new Date(filters.startDate as string));
    }
    if (filters.endDate) {
        filteredServices = filteredServices.filter(s => new Date(s.date) <= new Date(filters.endDate as string));
    }
    if (filters.q) {
        const query = filters.q.toLowerCase();
        filteredServices = filteredServices.filter(s => s.customerName.toLowerCase().includes(query) || s.bikeNumber.toLowerCase().includes(query));
    }

    return apiCall([...filteredServices].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
}

export const addBikeService = async (service: Omit<BikeService, 'id'>, addToSales: boolean): Promise<BikeService> => {
    const newService: BikeService = {
        ...service,
        id: `bs_${nextId++}`,
    };

    if (addToSales) {
        const newSale: Sale = {
            id: `sale_${nextId++}`,
            serviceName: `Service for ${service.bikeNumber}`,
            qty: 1,
            rate: service.serviceCost,
            totalAmount: service.serviceCost,
            paymentMethod: service.paymentMethod,
            date: service.date,
        };
        sales.unshift(newSale);
        newService.linkedSaleId = newSale.id;
    }
    bikeServices.unshift(newService);
    saveDB();
    return apiCall(newService);
}

export const updateBikeService = async (id: string, updatedService: Partial<BikeService>): Promise<BikeService> => {
    const index = bikeServices.findIndex(e => e.id === id);
    if (index === -1) throw new Error("Bike service not found");
    bikeServices[index] = { ...bikeServices[index], ...updatedService };
    saveDB();
    return apiCall(bikeServices[index]);
}


export const deleteBikeService = async (id: string): Promise<{ success: boolean }> => {
    const service = bikeServices.find(bs => bs.id === id);
    if (service?.linkedSaleId) {
        sales = sales.filter(s => s.id !== service.linkedSaleId);
    }
    bikeServices = bikeServices.filter(bs => bs.id !== id);
    saveDB();
    return apiCall({ success: true });
}

// FIX: Implement CRUD operations for Bike Specifications to fix errors in pages/Settings.tsx.
// --- Bike Specs API ---
export const getBikeSpecs = async (): Promise<BikeSpec[]> => {
    return apiCall([...bikeSpecs].sort((a, b) => a.brand.localeCompare(b.brand) || a.model.localeCompare(b.model)));
}

export const addBikeSpec = async (spec: Omit<BikeSpec, 'id'>): Promise<BikeSpec> => {
    const newSpec: BikeSpec = {
        ...spec,
        id: `spec_${nextId++}`,
    };
    bikeSpecs.unshift(newSpec);
    saveDB();
    return apiCall(newSpec);
}

export const updateBikeSpec = async (id: string, updatedSpec: Partial<BikeSpec>): Promise<BikeSpec> => {
    const index = bikeSpecs.findIndex(s => s.id === id);
    if (index === -1) throw new Error("Bike spec not found");
    
    bikeSpecs[index] = { ...bikeSpecs[index], ...updatedSpec };
    saveDB();
    return apiCall(bikeSpecs[index]);
}

export const deleteBikeSpec = async (id: string): Promise<{ success: boolean }> => {
    bikeSpecs = bikeSpecs.filter(s => s.id !== id);
    saveDB();
    return apiCall({ success: true });
}

// --- Reports API ---

const getSummaryForPeriod = (startDate?: string, endDate?: string): ProfitLossSummary => {
    let relevantSales = sales;
    let relevantExpenses = expenses;

    if (startDate) {
        relevantSales = relevantSales.filter(s => new Date(s.date) >= new Date(startDate));
        relevantExpenses = relevantExpenses.filter(e => new Date(e.date) >= new Date(startDate));
    }
    if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        relevantSales = relevantSales.filter(s => new Date(s.date) <= end);
        relevantExpenses = relevantExpenses.filter(e => new Date(e.date) <= end);
    }

    const salesCash = relevantSales.filter(s => s.paymentMethod === 'Cash').reduce((acc, s) => acc + s.totalAmount, 0);
    const salesGPay = relevantSales.filter(s => s.paymentMethod === 'GPay').reduce((acc, s) => acc + s.totalAmount, 0);
    const totalSales = salesCash + salesGPay;
    const totalExpenses = relevantExpenses.reduce((acc, e) => acc + e.amount, 0);
    const netProfit = totalSales - totalExpenses;

    return { salesCash, salesGPay, totalSales, totalExpenses, netProfit };
}

export const getDashboardData = async (filters: { startDate?: string, endDate?: string }): Promise<DashboardData> => {
    const summary = getSummaryForPeriod(filters.startDate, filters.endDate);
    
    // Create mock daily profit data
    const dailyProfit: { date: string; profit: number }[] = [];
    const dateRange = 14; // last 14 days
    for (let i = dateRange - 1; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        
        const daySales = sales.filter(s => s.date.startsWith(dateStr)).reduce((acc, s) => acc + s.totalAmount, 0);
        const dayExpenses = expenses.filter(e => e.date.startsWith(dateStr)).reduce((acc, e) => acc + e.amount, 0);
        dailyProfit.push({
            date: date.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }),
            profit: daySales - dayExpenses
        });
    }

    return apiCall({ ...summary, dailyProfit });
}

export const getProfitLossReport = async (filters: { startDate?: string, endDate?: string }): Promise<ProfitLossSummary> => {
    return apiCall(getSummaryForPeriod(filters.startDate, filters.endDate));
}