
import type { User } from '../types';

const USERS_KEY = 'bikeShopUsers';
const SESSION_KEY = 'bikeShopSession';
const OTP_RESET_KEY = 'bikeShopOtpReset';

// This is a simple pseudo-hash for demonstration purposes.
// In a real-world application, hashing MUST be performed on the server-side
// using a strong, salted hashing algorithm like bcrypt or Argon2.
const pseudoHash = (password: string): string => {
    // A simple base64 encoding to avoid storing in plain text. NOT secure.
    return btoa(password.split('').reverse().join(''));
};

const getUsers = (): User[] => {
    try {
        const usersStr = localStorage.getItem(USERS_KEY);
        return usersStr ? JSON.parse(usersStr) : [];
    } catch (e) {
        return [];
    }
};

const saveUsers = (users: User[]) => {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const register = async (username: string, email: string, password: string, phone: string): Promise<User> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const users = getUsers();
            if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
                return reject(new Error('User with this email already exists.'));
            }
            if (users.find(u => u.phone === phone)) {
                return reject(new Error('User with this phone number already exists.'));
            }
            const newUser: User = {
                id: `user_${Date.now()}`,
                username,
                email,
                phone,
                passwordHash: pseudoHash(password)
            };
            users.push(newUser);
            saveUsers(users);
            resolve(newUser);
        }, 500);
    });
};

export const login = async (email: string, password: string): Promise<User> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const users = getUsers();
            const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
            if (!user || user.passwordHash !== pseudoHash(password)) {
                return reject(new Error('Invalid email or password.'));
            }
            
            const sessionToken = btoa(JSON.stringify({ userId: user.id, email: user.email }));
            localStorage.setItem(SESSION_KEY, sessionToken);
            
            resolve(user);
        }, 500);
    });
};

export const logout = (): void => {
    localStorage.removeItem(SESSION_KEY);
};

export const getCurrentUser = (): User | null => {
    try {
        const token = localStorage.getItem(SESSION_KEY);
        if (!token) return null;
        
        const decoded = JSON.parse(atob(token));
        if (!decoded.userId) return null;
        
        const users = getUsers();
        const user = users.find(u => u.id === decoded.userId);
        return user || null;
    } catch (e) {
        return null;
    }
};

// --- OTP Password Reset ---

export const requestPasswordReset = async (phone: string): Promise<{ message: string; otp: string }> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const users = getUsers();
            const user = users.find(u => u.phone === phone);
            if (!user) {
                return reject(new Error("No account found with this phone number."));
            }
            
            // Simulate OTP generation
            const otp = Math.floor(100000 + Math.random() * 900000).toString();
            console.log(`OTP for ${phone} is: ${otp}`); // For debugging
            
            const otpData = {
                userId: user.id,
                otp,
                expires: Date.now() + 5 * 60 * 1000, // OTP valid for 5 minutes
            };
            sessionStorage.setItem(OTP_RESET_KEY, JSON.stringify(otpData));
            
            // In a real app, you would send the OTP via SMS here.
            // We resolve with the OTP for simulation purposes.
            resolve({
                message: `An OTP has been generated for testing.`,
                otp: otp
            });
        }, 500);
    });
};


export const verifyOtpAndResetPassword = async (otp: string, newPassword: string): Promise<User> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const otpDataStr = sessionStorage.getItem(OTP_RESET_KEY);
            if (!otpDataStr) {
                return reject(new Error("No active password reset request. Please try again."));
            }

            const otpData = JSON.parse(otpDataStr);
            if (Date.now() > otpData.expires) {
                sessionStorage.removeItem(OTP_RESET_KEY);
                return reject(new Error("OTP has expired. Please request a new one."));
            }
            if (otpData.otp !== otp) {
                return reject(new Error("Invalid OTP."));
            }

            let users = getUsers();
            const userIndex = users.findIndex(u => u.id === otpData.userId);
            if (userIndex === -1) {
                return reject(new Error("User not found."));
            }
            
            users[userIndex].passwordHash = pseudoHash(newPassword);
            saveUsers(users);
            
            sessionStorage.removeItem(OTP_RESET_KEY);
            
            resolve(users[userIndex]);

        }, 500);
    });
};