
import React, { useState, useEffect, useCallback } from 'react';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import PageHeader from '../components/shared/PageHeader';
import Modal from '../components/ui/Modal';
import { getBikeSpecs, addBikeSpec, updateBikeSpec, deleteBikeSpec } from '../services/api';
import type { BikeSpec } from '../types';
import { formatCurrency } from '../utils/formatters';
import { Plus, Trash2, Edit, X } from 'lucide-react';
import BackButton from '../components/shared/BackButton';

const emptySpec: Omit<BikeSpec, 'id'> = {
  brand: '',
  model: '',
  engineCC: 0,
  mileage: 0,
  price: 0,
};

const Settings: React.FC = () => {
  const [specs, setSpecs] = useState<BikeSpec[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [formState, setFormState] = useState(emptySpec);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [specToDelete, setSpecToDelete] = useState<string | null>(null);

  const fetchSpecs = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await getBikeSpecs();
      setSpecs(data);
    } catch (error) {
      console.error("Failed to fetch bike specs", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSpecs();
  }, [fetchSpecs]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const processedValue = (name === 'engineCC' || name === 'mileage' || name === 'price') 
        ? Math.max(0, parseInt(value, 10) || 0)
        : value;
    setFormState(prev => ({ ...prev, [name]: processedValue }));
  };

  const resetForm = () => {
    setFormState(emptySpec);
    setEditingId(null);
  };
  
  const handleEdit = (spec: BikeSpec) => {
      setEditingId(spec.id);
      setFormState({
          brand: spec.brand,
          model: spec.model,
          engineCC: spec.engineCC,
          mileage: spec.mileage,
          price: spec.price,
      });
      window.scrollTo({top: 0, behavior: 'smooth'});
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
     if (!formState.brand || !formState.model || formState.price <= 0) {
        alert('Please fill in Brand, Model and a valid Price.');
        return;
    }
    
    try {
        if (editingId) {
            await updateBikeSpec(editingId, formState);
        } else {
            await addBikeSpec(formState);
        }
        fetchSpecs();
        resetForm();
    } catch(error) {
        console.error("Failed to save bike spec", error);
    }
  };
  
  const openDeleteModal = (id: string) => {
    setSpecToDelete(id);
    setIsModalOpen(true);
  };

  const handleDelete = async () => {
    if (specToDelete) {
        try {
            await deleteBikeSpec(specToDelete);
            fetchSpecs();
            setIsModalOpen(false);
            setSpecToDelete(null);
        } catch (error) {
            console.error("Failed to delete bike spec", error);
        }
    }
  };

  return (
    <>
      <BackButton />
      <PageHeader title="Bike Specifications" />
      
      <Card className="mb-8">
        <form onSubmit={handleSubmit}>
          <h3 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">{editingId ? 'Edit Specification' : 'Add New Specification'}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <Input label="Brand" name="brand" id="brand" value={formState.brand} onChange={handleInputChange} required />
            <Input label="Model" name="model" id="model" value={formState.model} onChange={handleInputChange} required />
            <Input label="Engine (CC)" name="engineCC" id="engineCC" type="number" value={formState.engineCC} onChange={handleInputChange} />
            <Input label="Mileage (kmpl)" name="mileage" id="mileage" type="number" value={formState.mileage} onChange={handleInputChange} />
            <Input label="Price (₹)" name="price" id="price" type="number" value={formState.price} onChange={handleInputChange} required />
          </div>
          <div className="mt-6 flex items-center justify-end gap-4">
             <Button type="button" variant="secondary" onClick={resetForm} Icon={X}>Cancel</Button>
             <Button type="submit" Icon={Plus}>{editingId ? 'Update Spec' : 'Add Spec'}</Button>
          </div>
        </form>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Saved Specifications</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {['Brand', 'Model', 'Engine (CC)', 'Mileage (kmpl)', 'Price', 'Actions'].map(h => (
                    <th key={h} scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {isLoading ? (
                <tr><td colSpan={6} className="text-center p-4">Loading specifications...</td></tr>
              ) : specs.map(spec => (
                <tr key={spec.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{spec.brand}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">{spec.model}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{spec.engineCC} cc</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{spec.mileage} kmpl</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-800">{formatCurrency(spec.price)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onClick={() => handleEdit(spec)} className="text-primary hover:text-primary-hover mr-4"><Edit size={18} /></button>
                    <button onClick={() => openDeleteModal(spec.id)} className="text-danger hover:text-danger-hover"><Trash2 size={18} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
       <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Confirm Deletion">
        <p className="text-gray-600 mb-6">Are you sure you want to delete this bike specification? This action cannot be undone.</p>
        <div className="flex justify-end gap-4">
          <Button variant="secondary" onClick={() => setIsModalOpen(false)}>Cancel</Button>
          <Button variant="danger" onClick={handleDelete}>Delete</Button>
        </div>
      </Modal>
    </>
  );
};

export default Settings;