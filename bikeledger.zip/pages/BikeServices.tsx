
import React, { useState, useEffect, useCallback } from 'react';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import Button from '../components/ui/Button';
import PageHeader from '../components/shared/PageHeader';
import Modal from '../components/ui/Modal';
import { getBikeServices, addBikeService, updateBikeService, deleteBikeService } from '../services/api';
import type { BikeService } from '../types';
import { PaymentMethod } from '../types';
import { formatCurrency, formatDate, formatInputDate } from '../utils/formatters';
import { Plus, Trash2, Edit, X, Link } from 'lucide-react';
import BackButton from '../components/shared/BackButton';

const emptyService: Omit<BikeService, 'id'> = {
    customerName: '',
    phone: '',
    bikeNumber: '',
    serviceDetails: '',
    serviceCost: 0,
    paymentMethod: PaymentMethod.GPay,
    date: new Date().toISOString(),
};

const BikeServices: React.FC = () => {
    const [services, setServices] = useState<BikeService[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [formState, setFormState] = useState(emptyService);
    const [editingId, setEditingId] = useState<string | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [serviceToDelete, setServiceToDelete] = useState<string | null>(null);
    const [addToSales, setAddToSales] = useState(true);

    const fetchServices = useCallback(async () => {
        setIsLoading(true);
        try {
            const data = await getBikeServices({});
            setServices(data);
        } catch (error) {
            console.error("Failed to fetch bike services", error);
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchServices();
    }, [fetchServices]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        let processedValue: string | number = value;

        if (name === 'serviceCost') {
            processedValue = Math.max(0, parseFloat(value) || 0);
        }
        setFormState(prev => ({ ...prev, [name]: processedValue }));
    };
    
    const resetForm = () => {
        setFormState(emptyService);
        setEditingId(null);
        setAddToSales(true);
    };

    const handleEdit = (service: BikeService) => {
        setEditingId(service.id);
        setFormState({
            customerName: service.customerName,
            phone: service.phone,
            bikeNumber: service.bikeNumber,
            serviceDetails: service.serviceDetails,
            serviceCost: service.serviceCost,
            paymentMethod: service.paymentMethod,
            date: service.date,
        });
        setAddToSales(!!service.linkedSaleId);
        window.scrollTo({top: 0, behavior: 'smooth'});
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (formState.serviceCost <= 0) {
            alert('Service cost must be greater than zero.');
            return;
        }
        try {
            if (editingId) {
                await updateBikeService(editingId, formState);
            } else {
                await addBikeService(formState, addToSales);
            }
            fetchServices();
            resetForm();
        } catch(error) {
            console.error("Failed to save bike service", error);
        }
    };
    
    const openDeleteModal = (id: string) => {
        setServiceToDelete(id);
        setIsModalOpen(true);
    };

    const handleDelete = async () => {
        if (serviceToDelete) {
            try {
                await deleteBikeService(serviceToDelete);
                fetchServices();
                setIsModalOpen(false);
                setServiceToDelete(null);
            } catch (error) {
                console.error("Failed to delete service", error);
            }
        }
    };

    return (
        <>
            <BackButton />
            <PageHeader title="Bike Service List" />
            <Card className="mb-8">
                <form onSubmit={handleSubmit}>
                    <h3 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">{editingId ? 'Edit Service' : 'Add New Service'}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <Input label="Customer Name" name="customerName" id="customerName" value={formState.customerName} onChange={handleInputChange} required />
                        <Input label="Phone (Optional)" name="phone" id="phone" type="tel" value={formState.phone} onChange={handleInputChange} />
                        <Input label="Bike Number" name="bikeNumber" id="bikeNumber" value={formState.bikeNumber} onChange={handleInputChange} required />
                        <Input label="Service Cost (₹)" name="serviceCost" id="serviceCost" type="number" value={formState.serviceCost} onChange={handleInputChange} min="0" />
                        <Select label="Payment" name="paymentMethod" id="paymentMethod" value={formState.paymentMethod} onChange={handleInputChange}>
                            <option value={PaymentMethod.GPay}>GPay</option>
                            <option value={PaymentMethod.Cash}>Cash</option>
                        </Select>
                        <Input label="Date" name="date" id="date" type="date" value={formatInputDate(formState.date)} onChange={(e) => setFormState(p => ({...p, date: new Date(e.target.value).toISOString()}))} />
                        <div className="md:col-span-2 lg:col-span-3">
                             <label htmlFor="serviceDetails" className="block text-sm font-medium text-gray-700 mb-1">Service Details</label>
                            <textarea id="serviceDetails" name="serviceDetails" rows={3} value={formState.serviceDetails} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"></textarea>
                        </div>
                    </div>
                    <div className="mt-6 flex items-center justify-between">
                        {!editingId && (
                             <div className="flex items-center">
                                <input id="addToSales" name="addToSales" type="checkbox" checked={addToSales} onChange={(e) => setAddToSales(e.target.checked)} className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded" />
                                <label htmlFor="addToSales" className="ml-2 block text-sm text-gray-900">Add to Counter Sales</label>
                            </div>
                        )}
                        <div className="flex-grow"></div>
                        <div className="flex items-center gap-4">
                            <Button type="button" variant="secondary" onClick={resetForm} Icon={X}>Cancel</Button>
                            <Button type="submit" Icon={Plus}>{editingId ? 'Update Service' : 'Save Service'}</Button>
                        </div>
                    </div>
                </form>
            </Card>

            <Card>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Service History</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                {['Date', 'Customer', 'Bike No.', 'Cost', 'Payment', 'Added to Sales', 'Actions'].map(h => (
                                    <th key={h} scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {isLoading ? (
                                <tr><td colSpan={7} className="text-center p-4">Loading...</td></tr>
                            ) : services.map(service => (
                                <tr key={service.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{formatDate(service.date)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{service.customerName}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{service.bikeNumber}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-800">{formatCurrency(service.serviceCost)}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${service.paymentMethod === 'GPay' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>
                                            {service.paymentMethod}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 text-center">
                                        {service.linkedSaleId ? <Link size={18} className="text-success" /> : '-'}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <button onClick={() => handleEdit(service)} className="text-primary hover:text-primary-hover mr-4"><Edit size={18} /></button>
                                        <button onClick={() => openDeleteModal(service.id)} className="text-danger hover:text-danger-hover"><Trash2 size={18} /></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>

            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Confirm Deletion">
                <p className="text-gray-600 mb-6">Are you sure you want to delete this service record? If it was added to sales, the corresponding sale entry will also be removed. This action cannot be undone.</p>
                <div className="flex justify-end gap-4">
                    <Button variant="secondary" onClick={() => setIsModalOpen(false)}>Cancel</Button>
                    <Button variant="danger" onClick={handleDelete}>Delete</Button>
                </div>
            </Modal>
        </>
    );
};

export default BikeServices;