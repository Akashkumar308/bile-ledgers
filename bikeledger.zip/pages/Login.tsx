
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { Bike, LogIn } from 'lucide-react';
import BackButton from '../components/shared/BackButton';

const Login: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const { login } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        try {
            await login(email, password);
            navigate('/dashboard');
        } catch (err: any) {
            setError(err.message || 'Failed to log in.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4 relative">
            <div className="absolute top-4 left-4">
              <BackButton className="mb-0" />
            </div>
            <div className="max-w-md w-full mx-auto">
                <div className="flex items-center justify-center mb-6">
                    <Bike className="h-10 w-10 text-primary" />
                    <h1 className="text-3xl font-bold text-gray-800 ml-2">BikeLedger</h1>
                </div>
                <Card>
                    <h2 className="text-xl font-semibold text-center text-gray-800 mb-1">Welcome Back!</h2>
                    <p className="text-center text-gray-500 mb-6">Sign in to continue</p>
                    {error && <p className="bg-danger-light text-danger-text text-sm p-3 rounded-md mb-4">{error}</p>}
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <Input 
                            label="Email Address" 
                            id="email" 
                            type="email" 
                            value={email} 
                            onChange={(e) => setEmail(e.target.value)} 
                            required 
                            placeholder="you@example.com"
                        />
                        <Input 
                            label="Password" 
                            id="password" 
                            type="password" 
                            value={password} 
                            onChange={(e) => setPassword(e.target.value)} 
                            required 
                            placeholder="••••••••"
                        />
                        <div className="text-right text-sm">
                            <Link to="/forgot-password" className="font-medium text-primary hover:text-primary-hover">
                                Forgot Password?
                            </Link>
                        </div>
                        <Button type="submit" disabled={loading} className="w-full" Icon={LogIn}>
                            {loading ? 'Signing In...' : 'Sign In'}
                        </Button>
                    </form>
                    <p className="text-sm text-center text-gray-600 mt-6">
                        Don't have an account?{' '}
                        <Link to="/register" className="font-medium text-primary hover:text-primary-hover">
                            Sign Up
                        </Link>
                    </p>
                </Card>
            </div>
        </div>
    );
};

export default Login;