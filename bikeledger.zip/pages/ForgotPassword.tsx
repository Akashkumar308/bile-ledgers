
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { requestPasswordReset, verifyOtpAndResetPassword } from '../services/auth';
import { Bike, KeyRound, CheckCircle } from 'lucide-react';
import BackButton from '../components/shared/BackButton';

type Step = 'phone' | 'otp' | 'success';

const ForgotPassword = () => {
    const [step, setStep] = useState<Step>('phone');
    const [phone, setPhone] = useState('');
    const [otp, setOtp] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    
    const [error, setError] = useState('');
    const [message, setMessage] = useState('');
    const [loading, setLoading] = useState(false);
    
    const navigate = useNavigate();

    const handlePhoneSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setMessage('');
        if (!/^\d{10}$/.test(phone)) {
            setError('Please enter a valid 10-digit phone number.');
            return;
        }
        setLoading(true);
        try {
            const { message, otp } = await requestPasswordReset(phone);
            setMessage(`${message} Your test OTP is: ${otp}`);
            setStep('otp');
        } catch (err: any) {
            setError(err.message || 'Failed to request password reset.');
        } finally {
            setLoading(false);
        }
    };

    const handleOtpSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setMessage('');
        if (newPassword !== confirmPassword) {
            setError('Passwords do not match.');
            return;
        }
        if (newPassword.length < 6) {
            setError('Password must be at least 6 characters long.');
            return;
        }
        setLoading(true);
        try {
            await verifyOtpAndResetPassword(otp, newPassword);
            setMessage('Password has been reset successfully!');
            setStep('success');
        } catch (err: any) {
            setError(err.message || 'Failed to reset password.');
        } finally {
            setLoading(false);
        }
    };
    
    const renderContent = () => {
        switch(step) {
            case 'phone':
                return (
                    <form onSubmit={handlePhoneSubmit} className="space-y-4">
                        <p className="text-center text-gray-500 mb-6">Enter your registered phone number to receive an OTP.</p>
                        <Input 
                            label="Phone Number" 
                            id="phone" 
                            type="tel" 
                            value={phone} 
                            onChange={(e) => setPhone(e.target.value)} 
                            required 
                            placeholder="9876543210"
                        />
                        <Button type="submit" disabled={loading} className="w-full" Icon={KeyRound}>
                            {loading ? 'Sending OTP...' : 'Send OTP'}
                        </Button>
                    </form>
                );
            case 'otp':
                return (
                    <form onSubmit={handleOtpSubmit} className="space-y-4">
                        <p className="text-center text-gray-500 mb-6">Enter the OTP and set your new password.</p>
                        <Input
                            label="OTP"
                            id="otp"
                            type="text"
                            value={otp}
                            onChange={(e) => setOtp(e.target.value)}
                            required
                            placeholder="Enter 6-digit OTP"
                        />
                        <Input 
                            label="New Password" 
                            id="newPassword" 
                            type="password" 
                            value={newPassword} 
                            onChange={(e) => setNewPassword(e.target.value)} 
                            required 
                            placeholder="••••••••"
                        />
                         <Input 
                            label="Confirm New Password" 
                            id="confirmPassword" 
                            type="password" 
                            value={confirmPassword} 
                            onChange={(e) => setConfirmPassword(e.target.value)} 
                            required 
                            placeholder="••••••••"
                        />
                        <Button type="submit" disabled={loading} className="w-full" Icon={KeyRound}>
                            {loading ? 'Resetting...' : 'Reset Password'}
                        </Button>
                    </form>
                );
            case 'success':
                 return (
                    <div className="text-center">
                        <CheckCircle className="h-16 w-16 text-success mx-auto mb-4" />
                        <h2 className="text-xl font-semibold text-gray-800 mb-2">Password Reset!</h2>
                        <p className="text-gray-600 mb-6">{message}</p>
                        <Button onClick={() => navigate('/login')} className="w-full">
                            Back to Login
                        </Button>
                    </div>
                 );
        }
    }

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4 relative">
             <div className="absolute top-4 left-4">
              <BackButton className="mb-0" />
            </div>
            <div className="max-w-md w-full mx-auto">
                <div className="flex items-center justify-center mb-6">
                    <Bike className="h-10 w-10 text-primary" />
                    <h1 className="text-3xl font-bold text-gray-800 ml-2">BikeLedger</h1>
                </div>
                <Card>
                    <h2 className="text-xl font-semibold text-center text-gray-800 mb-1">Forgot Password</h2>
                    {error && <p className="bg-danger-light text-danger-text text-sm p-3 rounded-md my-4">{error}</p>}
                    {message && !error && step !== 'success' && <p className="bg-success-light text-success-text text-sm p-3 rounded-md my-4">{message}</p>}

                    {renderContent()}

                    {step !== 'success' && (
                        <p className="text-sm text-center text-gray-600 mt-6">
                            Remember your password?{' '}
                            <Link to="/login" className="font-medium text-primary hover:text-primary-hover">
                                Sign In
                            </Link>
                        </p>
                    )}
                </Card>
            </div>
        </div>
    );
};

export default ForgotPassword;