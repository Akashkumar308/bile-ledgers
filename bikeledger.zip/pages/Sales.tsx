
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import Button from '../components/ui/Button';
import PageHeader from '../components/shared/PageHeader';
import Modal from '../components/ui/Modal';
import { getSales, addSale, updateSale, deleteSale } from '../services/api';
import type { Sale } from '../types';
import { PaymentMethod } from '../types';
import { formatCurrency, formatDate, formatInputDate } from '../utils/formatters';
import { Plus, Trash2, Edit, X } from 'lucide-react';
import BackButton from '../components/shared/BackButton';

const emptySale: Omit<Sale, 'id' | 'totalAmount'> = {
  serviceName: '',
  qty: 1,
  rate: 0,
  paymentMethod: PaymentMethod.GPay,
  date: new Date().toISOString(),
};

const Sales: React.FC = () => {
  const [sales, setSales] = useState<Sale[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [formState, setFormState] = useState(emptySale);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [saleToDelete, setSaleToDelete] = useState<string | null>(null);

  const totalAmount = useMemo(() => formState.qty * formState.rate, [formState.qty, formState.rate]);

  const fetchSales = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await getSales({});
      setSales(data);
    } catch (error) {
      console.error("Failed to fetch sales", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSales();
  }, [fetchSales]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    let processedValue: string | number = value;

    if (name === 'qty' || name === 'rate') {
      processedValue = Math.max(0, parseFloat(value) || 0);
    }
    setFormState(prev => ({ ...prev, [name]: processedValue }));
  };

  const resetForm = () => {
    setFormState(emptySale);
    setEditingId(null);
  };
  
  const handleEdit = (sale: Sale) => {
      setEditingId(sale.id);
      setFormState({
          serviceName: sale.serviceName,
          qty: sale.qty,
          rate: sale.rate,
          paymentMethod: sale.paymentMethod,
          date: sale.date,
      });
      window.scrollTo({top: 0, behavior: 'smooth'});
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (totalAmount <= 0) {
        alert('Total amount must be greater than zero.');
        return;
    }
    const saleData = { ...formState, totalAmount };
    
    try {
        if (editingId) {
            await updateSale(editingId, saleData);
        } else {
            await addSale(formState);
        }
        fetchSales();
        resetForm();
    } catch(error) {
        console.error("Failed to save sale", error);
    }
  };
  
  const openDeleteModal = (id: string) => {
    setSaleToDelete(id);
    setIsModalOpen(true);
  };

  const handleDelete = async () => {
    if (saleToDelete) {
        try {
            await deleteSale(saleToDelete);
            fetchSales();
            setIsModalOpen(false);
            setSaleToDelete(null);
        } catch (error) {
            console.error("Failed to delete sale", error);
        }
    }
  };


  return (
    <>
      <BackButton />
      <PageHeader title="Counter Sales" />
      
      <Card className="mb-8">
        <form onSubmit={handleSubmit}>
          <h3 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">{editingId ? 'Edit Sale' : 'Add New Sale'}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <Input label="Service Name" name="serviceName" id="serviceName" value={formState.serviceName} onChange={handleInputChange} required />
            <Input label="Quantity" name="qty" id="qty" type="number" value={formState.qty} onChange={handleInputChange} min="1" />
            <Input label="Rate (₹)" name="rate" id="rate" type="number" value={formState.rate} onChange={handleInputChange} min="0" />
            <Select label="Payment" name="paymentMethod" id="paymentMethod" value={formState.paymentMethod} onChange={handleInputChange}>
              <option value={PaymentMethod.GPay}>GPay</option>
              <option value={PaymentMethod.Cash}>Cash</option>
            </Select>
            <Input label="Date" name="date" id="date" type="date" value={formatInputDate(formState.date)} onChange={(e) => setFormState(p => ({...p, date: new Date(e.target.value).toISOString()}))} />
          </div>
          <div className="mt-6 p-4 bg-gray-50 rounded-lg flex items-center justify-between sticky bottom-0">
             <div>
                <span className="text-gray-600">Total Amount:</span>
                <span className="text-2xl font-bold text-primary ml-2">{formatCurrency(totalAmount)}</span>
             </div>
             <div className="flex items-center gap-4">
                <Button type="button" variant="secondary" onClick={resetForm} Icon={X}>Cancel</Button>
                <Button type="submit" Icon={Plus}>{editingId ? 'Update Sale' : 'Add Sale'}</Button>
             </div>
          </div>
        </form>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Sales History</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {['Date', 'Service', 'Qty', 'Rate', 'Total', 'Payment', 'Actions'].map(h => (
                    <th key={h} scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {isLoading ? (
                <tr><td colSpan={7} className="text-center p-4">Loading...</td></tr>
              ) : sales.map(sale => (
                <tr key={sale.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{formatDate(sale.date)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{sale.serviceName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{sale.qty}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{formatCurrency(sale.rate)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-800">{formatCurrency(sale.totalAmount)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${sale.paymentMethod === 'GPay' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>
                      {sale.paymentMethod}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onClick={() => handleEdit(sale)} className="text-primary hover:text-primary-hover mr-4"><Edit size={18} /></button>
                    <button onClick={() => openDeleteModal(sale.id)} className="text-danger hover:text-danger-hover"><Trash2 size={18} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
       <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Confirm Deletion">
        <p className="text-gray-600 mb-6">Are you sure you want to delete this sale record? This action cannot be undone.</p>
        <div className="flex justify-end gap-4">
          <Button variant="secondary" onClick={() => setIsModalOpen(false)}>Cancel</Button>
          <Button variant="danger" onClick={handleDelete}>Delete</Button>
        </div>
      </Modal>
    </>
  );
};

export default Sales;