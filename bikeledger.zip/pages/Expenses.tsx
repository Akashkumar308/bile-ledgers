
import React, { useState, useEffect, useCallback } from 'react';
import Card from '../components/ui/Card';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import PageHeader from '../components/shared/PageHeader';
import Modal from '../components/ui/Modal';
import { getExpenses, getExpenseCategories, addExpense, updateExpense, deleteExpense } from '../services/api';
import type { Expense } from '../types';
import { formatCurrency, formatDate, formatInputDate } from '../utils/formatters';
import { Plus, Trash2, Edit, X } from 'lucide-react';
import BackButton from '../components/shared/BackButton';

const emptyExpense: Omit<Expense, 'id'> = {
  category: '',
  description: '',
  amount: 0,
  date: new Date().toISOString(),
};

const Expenses: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [formState, setFormState] = useState(emptyExpense);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [expenseToDelete, setExpenseToDelete] = useState<string | null>(null);
  const [newCategory, setNewCategory] = useState('');

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [expensesData, categoriesData] = await Promise.all([getExpenses({}), getExpenseCategories()]);
      setExpenses(expensesData);
      setCategories(categoriesData);
      if (categoriesData.length > 0 && !formState.category) {
          setFormState(prev => ({...prev, category: categoriesData[0]}));
      }
    } catch (error) {
      console.error("Failed to fetch expenses data", error);
    } finally {
      setIsLoading(false);
    }
  }, [formState.category]);

  useEffect(() => {
    fetchData();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    let processedValue: string | number = value;

    if (name === 'amount') {
      processedValue = Math.max(0, parseFloat(value) || 0);
    }
    setFormState(prev => ({ ...prev, [name]: processedValue }));
  };

  const handleCategorySelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
      if(e.target.value === 'add_new') {
          // logic to add new category can be handled via a modal or inline input
      } else {
          setFormState(prev => ({ ...prev, category: e.target.value }));
      }
  }

  const handleAddNewCategory = () => {
      if(newCategory && !categories.includes(newCategory)) {
          setCategories(prev => [...prev, newCategory]);
          setFormState(prev => ({...prev, category: newCategory}));
          setNewCategory('');
      }
  }

  const resetForm = () => {
    setFormState({...emptyExpense, category: categories[0] || ''});
    setEditingId(null);
  };
  
  const handleEdit = (expense: Expense) => {
      setEditingId(expense.id);
      setFormState({
          category: expense.category,
          description: expense.description,
          amount: expense.amount,
          date: expense.date,
      });
      window.scrollTo({top: 0, behavior: 'smooth'});
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.category) {
        alert('Please select or add a category.');
        return;
    }
    if (formState.amount <= 0) {
        alert('Amount must be greater than zero.');
        return;
    }
    
    try {
        if (editingId) {
            await updateExpense(editingId, formState);
        } else {
            await addExpense(formState);
        }
        fetchData();
        resetForm();
    } catch(error) {
        console.error("Failed to save expense", error);
    }
  };
  
  const openDeleteModal = (id: string) => {
    setExpenseToDelete(id);
    setIsModalOpen(true);
  };

  const handleDelete = async () => {
    if (expenseToDelete) {
        try {
            await deleteExpense(expenseToDelete);
            fetchData();
            setIsModalOpen(false);
            setExpenseToDelete(null);
        } catch (error) {
            console.error("Failed to delete expense", error);
        }
    }
  };


  return (
    <>
      <BackButton />
      <PageHeader title="Expenses" />
      
      <Card className="mb-8">
        <form onSubmit={handleSubmit}>
          <h3 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">{editingId ? 'Edit Expense' : 'Add New Expense'}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            <div className="lg:col-span-2">
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <div className="flex gap-2">
                    <select id="category" name="category" value={formState.category} onChange={handleCategorySelect} className="w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm">
                        <option value="" disabled>Select a category</option>
                        {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </select>
                </div>
                 <div className="flex gap-2 mt-2">
                     <input type="text" placeholder="Or add new category" value={newCategory} onChange={(e) => setNewCategory(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm" />
                     <Button type="button" onClick={handleAddNewCategory}>Add</Button>
                 </div>
            </div>
            <Input label="Description" name="description" id="description" value={formState.description} onChange={handleInputChange} required />
            <Input label="Amount (₹)" name="amount" id="amount" type="number" value={formState.amount} onChange={handleInputChange} min="0" />
            <Input label="Date" name="date" id="date" type="date" value={formatInputDate(formState.date)} onChange={(e) => setFormState(p => ({...p, date: new Date(e.target.value).toISOString()}))} />
          </div>
          <div className="mt-6 flex items-center justify-end gap-4">
             <Button type="button" variant="secondary" onClick={resetForm} Icon={X}>Cancel</Button>
             <Button type="submit" Icon={Plus}>{editingId ? 'Update Expense' : 'Add Expense'}</Button>
          </div>
        </form>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Expenses History</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {['Date', 'Category', 'Description', 'Amount', 'Actions'].map(h => (
                    <th key={h} scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {isLoading ? (
                <tr><td colSpan={5} className="text-center p-4">Loading...</td></tr>
              ) : expenses.map(exp => (
                <tr key={exp.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{formatDate(exp.date)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{exp.category}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{exp.description}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-800">{formatCurrency(exp.amount)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onClick={() => handleEdit(exp)} className="text-primary hover:text-primary-hover mr-4"><Edit size={18} /></button>
                    <button onClick={() => openDeleteModal(exp.id)} className="text-danger hover:text-danger-hover"><Trash2 size={18} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
       <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Confirm Deletion">
        <p className="text-gray-600 mb-6">Are you sure you want to delete this expense record? This action cannot be undone.</p>
        <div className="flex justify-end gap-4">
          <Button variant="secondary" onClick={() => setIsModalOpen(false)}>Cancel</Button>
          <Button variant="danger" onClick={handleDelete}>Delete</Button>
        </div>
      </Modal>
    </>
  );
};

export default Expenses;