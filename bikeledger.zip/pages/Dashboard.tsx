
import React, { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import StatCard from '../components/shared/StatCard';
import DateFilter from '../components/shared/DateFilter';
import Card from '../components/ui/Card';
import { getDashboardData } from '../services/api';
import type { DashboardData } from '../types';
import { useDateFilter } from '../hooks/useDateFilter';
import { formatCurrency } from '../utils/formatters';
import { TrendingUp, TrendingDown, IndianRupee, PieChart } from 'lucide-react';
import BackButton from '../components/shared/BackButton';

const Dashboard: React.FC = () => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const { filter, setFilter, dateRange } = useDateFilter('this_month');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const result = await getDashboardData(dateRange);
      setData(result);
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  if (loading || !data) {
    return (
      <>
        <BackButton />
        <div className="text-center p-8">Loading dashboard...</div>
      </>
    );
  }
  
  const netProfitColor = data.netProfit >= 0 ? '#16a34a' : '#ef4444';

  return (
    <div className="space-y-6">
      <BackButton className="mb-0"/>
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <DateFilter selected={filter} onChange={setFilter} />
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Sales" value={formatCurrency(data.totalSales)} Icon={TrendingUp} color="#2563eb" />
        <StatCard title="Total Expenses" value={formatCurrency(data.totalExpenses)} Icon={TrendingDown} color="#f59e0b" />
        <StatCard title="Net Profit" value={formatCurrency(data.netProfit)} Icon={IndianRupee} color={netProfitColor} />
        <StatCard title="Sales by GPay" value={formatCurrency(data.salesGPay)} Icon={PieChart} color="#3b82f6" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Weekly Profit Overview</h3>
            <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data.dailyProfit} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="date" fontSize={12} tickLine={false} axisLine={false}/>
                <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `₹${value/1000}k`} />
                <Tooltip 
                  cursor={{fill: 'rgba(37, 99, 235, 0.1)'}}
                  contentStyle={{ background: '#fff', border: '1px solid #ddd', borderRadius: '0.5rem' }} 
                  formatter={(value: number) => [formatCurrency(value), 'Profit']}
                />
                <Legend iconType="circle" iconSize={10} verticalAlign="top" align="right" />
                <Bar dataKey="profit" name="Net Profit" fill="#2563eb" radius={[4, 4, 0, 0]} />
            </BarChart>
            </ResponsiveContainer>
        </Card>
        <Card>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Sales by Payment</h3>
            <div className="space-y-4 pt-4">
                <div className="flex justify-between items-center">
                    <span className="text-gray-600">Cash Sales</span>
                    <span className="font-bold text-gray-800">{formatCurrency(data.salesCash)}</span>
                </div>
                <div className="flex justify-between items-center">
                    <span className="text-gray-600">GPay Sales</span>
                    <span className="font-bold text-gray-800">{formatCurrency(data.salesGPay)}</span>
                </div>
                 <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-primary h-2.5 rounded-l-full" style={{ width: `${(data.salesCash / data.totalSales) * 100}%` }}></div>
                </div>
                 <div className="flex justify-between text-sm text-gray-500">
                    <span>Cash</span>
                    <span>GPay</span>
                </div>
            </div>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;