
import React, { useState, useEffect, useCallback } from 'react';
import PageHeader from '../components/shared/PageHeader';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import DateFilter from '../components/shared/DateFilter';
import { getProfitLossReport, getSales, getExpenses } from '../services/api';
import type { ProfitLossSummary } from '../types';
import { useDateFilter } from '../hooks/useDateFilter';
import { formatCurrency, formatDate } from '../utils/formatters';
import { Download, FileText } from 'lucide-react';
import * as XLSX from 'xlsx';
import BackButton from '../components/shared/BackButton';

const ProfitAndLoss: React.FC = () => {
    const [summary, setSummary] = useState<ProfitLossSummary | null>(null);
    const [loading, setLoading] = useState(true);
    const { filter, setFilter, dateRange } = useDateFilter('this_month');

    const fetchReport = useCallback(async () => {
        setLoading(true);
        try {
            const result = await getProfitLossReport(dateRange);
            setSummary(result);
        } catch (error) {
            console.error("Failed to fetch P&L report:", error);
        } finally {
            setLoading(false);
        }
    }, [dateRange]);

    useEffect(() => {
        fetchReport();
    }, [fetchReport]);
    
    const handleExportExcel = async () => {
        if (!summary) return;

        setLoading(true);
        try {
            const [salesData, expensesData] = await Promise.all([
                getSales(dateRange),
                getExpenses(dateRange),
            ]);
            
            // 1. Summary Sheet
            const summaryExport = [
                { Item: 'Income' },
                { Item: 'Sales (Cash)', Amount: summary.salesCash },
                { Item: 'Sales (GPay)', Amount: summary.salesGPay },
                { Item: 'Total Sales', Amount: summary.totalSales },
                { Item: '' },
                { Item: 'Expenses' },
                { Item: 'Total Expenses', Amount: summary.totalExpenses },
                { Item: '' },
                { Item: 'Net Profit / (Loss)', Amount: summary.netProfit },
            ];
            const summarySheet = XLSX.utils.json_to_sheet(summaryExport, { skipHeader: true });

            // 2. Sales Sheet
            const salesExport = salesData.map(s => ({
                Date: formatDate(s.date),
                Service: s.serviceName,
                Quantity: s.qty,
                Rate: s.rate,
                Total: s.totalAmount,
                'Payment Method': s.paymentMethod
            }));
            const salesSheet = XLSX.utils.json_to_sheet(salesExport);

            // 3. Expenses Sheet
            const expensesExport = expensesData.map(e => ({
                Date: formatDate(e.date),
                Category: e.category,
                Description: e.description,
                Amount: e.amount
            }));
            const expensesSheet = XLSX.utils.json_to_sheet(expensesExport);
            
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, summarySheet, 'Summary');
            XLSX.utils.book_append_sheet(wb, salesSheet, 'Sales');
            XLSX.utils.book_append_sheet(wb, expensesSheet, 'Expenses');
            
            XLSX.writeFile(wb, 'Profit_And_Loss_Report.xlsx');
            
        } catch(error) {
            console.error("Failed to export data to Excel", error);
            alert("Could not export data. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    const SummaryRow = ({ label, value, isBold = false, isTotal = false, color = 'text-gray-800' }: {label: string, value: string, isBold?: boolean, isTotal?: boolean, color?: string}) => (
        <div className={`flex justify-between py-4 ${isTotal ? 'border-t-2 border-gray-300 font-semibold' : 'border-b border-gray-100'}`}>
            <span className={`text-gray-600 ${isBold ? 'font-semibold' : ''}`}>{label}</span>
            <span className={`${color} ${isBold ? 'font-bold' : ''}`}>{value}</span>
        </div>
    );

    return (
        <>
            <BackButton />
            <PageHeader title="Profit & Loss Statement">
                <Button variant="secondary" Icon={FileText}>Export PDF</Button>
                <Button variant="secondary" Icon={Download} onClick={handleExportExcel} disabled={loading}>
                    {loading ? 'Exporting...' : 'Export Excel'}
                </Button>
            </PageHeader>
            <div className="flex justify-end mb-6">
                <DateFilter selected={filter} onChange={setFilter} />
            </div>
            <Card>
                {loading || !summary ? (
                    <div className="text-center p-8">Generating report...</div>
                ) : (
                    <div className="max-w-3xl mx-auto">
                        <h3 className="text-xl font-bold text-center text-gray-900">Profit & Loss Summary</h3>
                        <p className="text-center text-gray-500 mb-8">For the period: {filter.replace('_', ' ')}</p>

                        <div className="space-y-2">
                           <h4 className="text-lg font-semibold text-gray-700 mt-6 mb-2">Income</h4>
                           <SummaryRow label="Sales (Cash)" value={formatCurrency(summary.salesCash)} />
                           <SummaryRow label="Sales (GPay)" value={formatCurrency(summary.salesGPay)} />
                           <SummaryRow label="Total Sales" value={formatCurrency(summary.totalSales)} isBold={true} />

                           <h4 className="text-lg font-semibold text-gray-700 mt-8 mb-2">Expenses</h4>
                           <SummaryRow label="Total Expenses" value={formatCurrency(summary.totalExpenses)} color="text-warning-text" />

                           <div className="pt-4">
                            <SummaryRow 
                                label="Net Profit / (Loss)" 
                                value={formatCurrency(summary.netProfit)} 
                                isBold={true} 
                                isTotal={true}
                                color={summary.netProfit >= 0 ? 'text-success-text' : 'text-danger-text'}
                            />
                           </div>
                        </div>
                    </div>
                )}
            </Card>
        </>
    );
};

export default ProfitAndLoss;