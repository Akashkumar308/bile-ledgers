
import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import * as authApi from '../services/auth';
import { initApiForUser, clearApiData } from '../services/api';
import type { User } from '../types';

interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (username: string, email: string, password: string, phone: string) => Promise<User>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkLoggedIn = () => {
      try {
        const user = authApi.getCurrentUser();
        if (user) {
          setCurrentUser(user);
          initApiForUser();
        }
      } catch (error) {
        console.error("Failed to check login status:", error);
        setCurrentUser(null);
      } finally {
        setLoading(false);
      }
    };
    checkLoggedIn();
  }, []);

  const login = async (email: string, password: string) => {
    const user = await authApi.login(email, password);
    setCurrentUser(user);
    initApiForUser();
    return user;
  };

  const register = async (username: string, email: string, password: string, phone: string) => {
    const user = await authApi.register(username, email, password, phone);
    // Optionally log them in directly after registration
    return login(email, password);
  };
  
  const logout = () => {
    authApi.logout();
    setCurrentUser(null);
    clearApiData();
  };

  const value = {
    currentUser,
    loading,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
